#include <tlhelp32.h>
// Invasion v5.0 guest-code experiment, applied at an emulated gun-read boundary.
// Both players share the same guest hit-test and screen-to-world routines.
using GunReadFn=uint32_t(__fastcall*)(void*,const uint32_t*);
static GunReadFn originalGunRead;
static bool guestAimRequested;
static void tryGuestAimPatch(BYTE *state){
 if(!guestAimRequested || !state)return;
 static ULONGLONG nextCheck=0;ULONGLONG now=GetTickCount64();if(now<nextCheck)return;nextCheck=now+250;
 BYTE *start=nullptr,*end=nullptr;SIZE_T got=0;
 if(!ReadProcessMemory(GetCurrentProcess(),state+0x50110,&start,sizeof(start),&got) ||
    !ReadProcessMemory(GetCurrentProcess(),state+0x50118,&end,sizeof(end),&got) ||
    !start || uintptr_t(end)<uintptr_t(start)+0x100000)return;
 auto readWords=[&](DWORD address,uint32_t *out,size_t count){SIZE_T n=0;return ReadProcessMemory(GetCurrentProcess(),start+address*4,out,count*4,&n)&&n==count*4;};
 const uint32_t rayOriginal[]={0x0fa30000,0x07030002,0x0a23afbe,0x17a0afa3,0x0a000003,0x17a1afa4,0x0a010003,0x0ea30000};
 const uint32_t hitOriginal[]={0x0a20ae0d,0x20c1038a,0x0a010000,0x01a1afa3,0x20c2044a,0x0a020000,0x01a2afa4};
 uint32_t ray[8],hit[7],gap[7];
 if(!readWords(0x1119b,ray,8)||!readWords(0xefa3,hit,7)||!readWords(0xc219,gap,7))return;
 if(ray[4]==0x6200c219 && hit[2]==0x6200c21c)return;
 if(memcmp(ray,rayOriginal,sizeof(ray))||memcmp(hit,hitOriginal,sizeof(hit))){
  static unsigned waits=0;if((waits++%20)==0)log("GUEST_AIM waiting: guest signatures differ ray_word=%08x hit_word=%08x\r\n",ray[4],hit[2]);return;
 }
 for(uint32_t word:gap)if(word){static unsigned waits=0;if((waits++%20)==0)log("GUEST_AIM skipped: guest helper gap is occupied first_word=%08x\r\n",gap[0]);return;}
 // Seven-word alignment gap between JUMPLOW and .text in the decoded COFF.
 // Full C3x float 0x002aaaab represents 4/3 to single-precision accuracy.
 const uint32_t helpers[]={0x0a000003,0x0a20c21f,0x78800000,0x0a010000,0x0a61f400,0x78800000,0x002aaaab};
 // This callback runs on the emulation thread, before executing either patched
 // guest instruction. Write helpers first, then switch the two aligned words.
 SIZE_T written=0;
 if(!WriteProcessMemory(GetCurrentProcess(),start+0xc219*4,helpers,sizeof(helpers),&written)||written!=sizeof(helpers)){log("GUEST_AIM helpers_write_failed\r\n");return;}
 const uint32_t rayCall=0x6200c219,hitCall=0x6200c21c;
 if(!WriteProcessMemory(GetCurrentProcess(),start+0x1119f*4,&rayCall,4,&written)||written!=4){WriteProcessMemory(GetCurrentProcess(),start+0xc219*4,gap,28,&written);log("GUEST_AIM ray_write_failed\r\n");return;}
 if(!WriteProcessMemory(GetCurrentProcess(),start+0xefa5*4,&hitCall,4,&written)||written!=4){WriteProcessMemory(GetCurrentProcess(),start+0x1119f*4,&rayOriginal[4],4,&written);WriteProcessMemory(GetCurrentProcess(),start+0xc219*4,gap,28,&written);log("GUEST_AIM hit_write_failed\r\n");return;}
 wchar_t readyName[96];swprintf(readyName,96,L"Local\\ZeusFullWidthAim-%lu",GetCurrentProcessId());
 HANDLE ready=CreateEventW(nullptr,TRUE,TRUE,readyName);
 log("FULL_WIDTH_AIM_EVENT handle=%p error=%lu\r\n",ready,ready?0:GetLastError());
 log("GUEST_AIM applied version=Invasion5 ray_guest=01119f hit_guest=00efa5 gain=1.3333333730697632 hit_scale=0.75 both_players=1\r\n");
}
static uint32_t __fastcall compensatedGunRead(void *closure,const uint32_t *address){
 BYTE *state=nullptr;SIZE_T got=0;
 if(ReadProcessMemory(GetCurrentProcess(),static_cast<BYTE*>(closure)+8,&state,sizeof(state),&got))tryGuestAimPatch(state);
 return originalGunRead(closure,address);
}
static void installGuestAimHook(BYTE *base,const wchar_t *ini){
 guestAimRequested=GetPrivateProfileIntW(L"Widescreen",L"FullWidthAim",0,ini)!=0;
 if(!guestAimRequested){log("GUEST_AIM disabled in INI\r\n");return;}
 const BYTE ramLayoutExpected[]={0x48,0x8b,0x81,0x10,0x01,0x05,0x00};
 BYTE ramLayoutActual[7];SIZE_T layoutBytes=0;
 if(!ReadProcessMemory(GetCurrentProcess(),base+0x7752c,ramLayoutActual,7,&layoutBytes)||memcmp(ramLayoutActual,ramLayoutExpected,7)){log("GUEST_AIM hook_skipped: RAM layout mismatch\r\n");return;}
 const BYTE expected[]={0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83,0xec,0x30,0x48,0x8b,0x59,0x08};
 BYTE actual[sizeof(expected)];SIZE_T got=0;
 if(!ReadProcessMemory(GetCurrentProcess(),base+0x76e90,actual,sizeof(actual),&got)||memcmp(actual,expected,sizeof(actual))){log("GUEST_AIM hook_skipped: gun-read instructions mismatch\r\n");return;}
 // Hook the already-validated function itself. No vtable-pointer assumption.
 BYTE *entry=base+0x76e90;
 BYTE *trampoline=static_cast<BYTE*>(VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
 if(!trampoline){log("GUEST_AIM hook_skipped: trampoline allocation failed\r\n");return;}
 memcpy(trampoline,expected,sizeof(expected));
 const BYTE absoluteJump[]={0xff,0x25,0,0,0,0};
 memcpy(trampoline+sizeof(expected),absoluteJump,6);void *continuation=entry+sizeof(expected);memcpy(trampoline+sizeof(expected)+6,&continuation,8);
 DWORD oldTrampoline;if(!VirtualProtect(trampoline,4096,PAGE_EXECUTE_READ,&oldTrampoline)){VirtualFree(trampoline,0,MEM_RELEASE);log("GUEST_AIM hook_skipped: trampoline protection failed\r\n");return;}
 FlushInstructionCache(GetCurrentProcess(),trampoline,4096);
 BYTE replacement[14];memcpy(replacement,absoluteJump,6);void *hook=reinterpret_cast<void*>(compensatedGunRead);memcpy(replacement+6,&hook,8);
 DWORD oldCode;if(!VirtualProtect(entry,sizeof(expected),PAGE_EXECUTE_READWRITE,&oldCode)){VirtualFree(trampoline,0,MEM_RELEASE);log("GUEST_AIM hook_skipped: entry protection failed\r\n");return;}
 std::vector<HANDLE> peers;peers.reserve(4096);bool safe=true;
 HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD,0);THREADENTRY32 t={};t.dwSize=sizeof(t);
 if(snapshot==INVALID_HANDLE_VALUE || !Thread32First(snapshot,&t))safe=false;
 else do{
  if(t.th32OwnerProcessID!=GetCurrentProcessId()||t.th32ThreadID==GetCurrentThreadId())continue;
  if(peers.size()==peers.capacity()){safe=false;break;}
  HANDLE thread=OpenThread(THREAD_SUSPEND_RESUME|THREAD_GET_CONTEXT,FALSE,t.th32ThreadID);
  if(!thread){safe=false;break;}if(SuspendThread(thread)==DWORD(-1)){CloseHandle(thread);safe=false;break;}
  peers.push_back(thread);CONTEXT context={};context.ContextFlags=CONTEXT_CONTROL;
  if(!GetThreadContext(thread,&context)){safe=false;break;}
  if(context.Rip>=reinterpret_cast<uintptr_t>(entry)&&context.Rip<reinterpret_cast<uintptr_t>(entry)+0xdc){safe=false;break;}
 }while(Thread32Next(snapshot,&t));
 if(snapshot!=INVALID_HANDLE_VALUE)CloseHandle(snapshot);
 if(safe && memcmp(entry,expected,sizeof(expected)))safe=false;
 if(safe){originalGunRead=reinterpret_cast<GunReadFn>(trampoline);memcpy(entry,replacement,sizeof(replacement));FlushInstructionCache(GetCurrentProcess(),entry,sizeof(replacement));}
 for(HANDLE thread:peers){ResumeThread(thread);CloseHandle(thread);}
 DWORD ignored;VirtualProtect(entry,sizeof(expected),oldCode,&ignored);
 if(!safe){VirtualFree(trampoline,0,MEM_RELEASE);log("GUEST_AIM hook_skipped: startup threads were not safe to patch\r\n");return;}
 log("GUEST_AIM direct hook installed RVA=00076e90; waiting for matching loaded game code\r\n");
}
