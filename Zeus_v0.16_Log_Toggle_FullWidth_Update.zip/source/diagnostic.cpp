#define WIN32_LEAN_AND_MEAN
#define WIDL_EXPLICIT_AGGREGATE_RETURNS
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <shellapi.h>
#include <cstdint>
#include <d3d11.h>
#include <d3d11_1.h>
#include <dxgi1_4.h>
#include <d3d10_1.h>
#include <d3d12.h>
#include <dinput.h>
#include <d3dcompiler.h>
#include <wincodec.h>
#include <cstdio>
#include <cstdarg>
#include <cwchar>
#include <new>
#include <vector>
#include <cstring>

static INIT_ONCE initOnce=INIT_ONCE_STATIC_INIT;
static SRWLOCK logLock=SRWLOCK_INIT;
static HANDLE logFile=INVALID_HANDLE_VALUE;
static HMODULE realD3D;
static volatile LONG64 frames;
using CreateFn=HRESULT(WINAPI*)(IDXGIAdapter*,D3D_DRIVER_TYPE,HMODULE,UINT,const D3D_FEATURE_LEVEL*,UINT,UINT,const DXGI_SWAP_CHAIN_DESC*,IDXGISwapChain**,ID3D11Device**,D3D_FEATURE_LEVEL*,ID3D11DeviceContext**);
using PresentFn=HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*,UINT,UINT);
static CreateFn realCreate;
static PresentFn realPresent;
using Present1Fn=HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain1*,UINT,UINT,const DXGI_PRESENT_PARAMETERS*);
static Present1Fn realPresent1;
static HWND probeWindow;
static SRWLOCK hookLock=SRWLOCK_INIT;
static HMODULE diagnosticModule;
static DWORD WINAPI investigateDXGI(LPVOID);
static void hookSwapChain(IDXGISwapChain*);

// Only basic file/path APIs run at process attach. LoadLibrary and graphics
// calls are deferred until an exported function executes outside loader lock.
static INIT_ONCE loggingOnce=INIT_ONCE_STATIC_INIT;
static bool loggingEnabled;
static BOOL CALLBACK initializeLogging(PINIT_ONCE,PVOID,PVOID*)
{
    wchar_t config[1024];DWORD configLength=GetModuleFileNameW(diagnosticModule,config,1024);
    if(!configLength || configLength>=1000)return TRUE;
    wchar_t *configSlash=wcsrchr(config,L'\\');if(!configSlash)return TRUE;
    wcscpy(configSlash+1,L"ZeusCrosshair.ini");
    loggingEnabled=GetPrivateProfileIntW(L"General",L"Logging",1,config)!=0;
    if(!loggingEnabled)return TRUE;
    if(logFile!=INVALID_HANDLE_VALUE)return TRUE;
    wchar_t path[1024];DWORD count=GetModuleFileNameW(diagnosticModule,path,1024);
    if(!count || count>=950)return TRUE;
    wchar_t *slash=wcsrchr(path,L'\\');if(!slash)return TRUE;slash[1]=0;
    wcscat(path,L"logs");
    if(!CreateDirectoryW(path,nullptr) && GetLastError()!=ERROR_ALREADY_EXISTS)return TRUE;
    wcscat(path,L"\\");
    wchar_t filename[80];swprintf(filename,80,L"zeus-crosshair-diagnostic-%lu.log",GetCurrentProcessId());
    wcscat(path,filename);
    logFile=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);
    if(logFile!=INVALID_HANDLE_VALUE){
        static const char marker[]="ZEUS_RUNTIME v0.16 DLL_PROCESS_ATTACH\r\n";
        DWORD written;WriteFile(logFile,marker,sizeof(marker)-1,&written,nullptr);FlushFileBuffers(logFile);
    }
    return TRUE;
}
static void openLog(){InitOnceExecuteOnce(&loggingOnce,initializeLogging,nullptr,nullptr);}
BOOL WINAPI DllMain(HINSTANCE instance,DWORD reason,LPVOID)
{
    if(reason==DLL_PROCESS_ATTACH){
        diagnosticModule=instance;
        wchar_t exe[1024];DWORD n=GetModuleFileNameW(nullptr,exe,1024);
        const wchar_t *name=n && n<1024?wcsrchr(exe,L'\\'):nullptr;
        if(name && _wcsicmp(name+1,L"TeknoZeus.exe")==0){
            // Do not wait under loader lock. The worker starts after attach returns.
            HANDLE thread=CreateThread(nullptr,2*1024*1024,investigateDXGI,nullptr,STACK_SIZE_PARAM_IS_A_RESERVATION,nullptr);
            if(thread)CloseHandle(thread);
        }
    }
    return TRUE;
}

static void log(const char *fmt,...)
{
    openLog();if(!loggingEnabled)return;
    char text[2048]; va_list args; va_start(args,fmt);
    int n=vsnprintf(text,sizeof(text),fmt,args);va_end(args);
    if(n<0)return;
    if(n>=int(sizeof(text)))n=sizeof(text)-1;
    OutputDebugStringA(text);
    AcquireSRWLockExclusive(&logLock);
    if(logFile!=INVALID_HANDLE_VALUE){DWORD written;WriteFile(logFile,text,n,&written,nullptr);FlushFileBuffers(logFile);}
    ReleaseSRWLockExclusive(&logLock);
}
#include "guest_aim_patch.h"
#include "widescreen_patch.h"
static BOOL CALLBACK initialize(PINIT_ONCE,PVOID,PVOID*)
{
    log("FORWARDER_INITIALIZE v0.16 x64 pid=%lu\r\n",GetCurrentProcessId());
    wchar_t exe[1024];GetModuleFileNameW(nullptr,exe,1024);log("Executable: %ls\r\n",exe);
    wchar_t system[1024];UINT n=GetSystemDirectoryW(system,1024);
    if(n && n+11<1024){wcscat(system,L"\\d3d11.dll");realD3D=LoadLibraryW(system);}
    if(realD3D)realCreate=reinterpret_cast<CreateFn>(GetProcAddress(realD3D,"D3D11CreateDeviceAndSwapChain"));
    HMODULE owner=nullptr;wchar_t ownerPath[1024]=L"unknown";
    if(realCreate && GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(realCreate),&owner))GetModuleFileNameW(owner,ownerPath,1024);
    log("FORWARDER_TARGET address=%p owner=%ls\r\n",reinterpret_cast<void*>(realCreate),ownerPath);
    if(owner==diagnosticModule){log("FORWARDER_RECURSION blocked: resolved export belongs to our proxy\r\n");realCreate=nullptr;}
    log("System D3D11 loaded=%d create_resolved=%d error=%lu\r\n",realD3D!=nullptr,realCreate!=nullptr,GetLastError());
    return TRUE;
}
extern "C" __declspec(dllexport) void CALLBACK ZeusDiagnosticSelfTest(HWND,HINSTANCE,LPSTR,int)
{
    InitOnceExecuteOnce(&initOnce,initialize,nullptr,nullptr);
    log("SELF_TEST log_handle_valid=%d system_forwarder_resolved=%d\r\n",logFile!=INVALID_HANDLE_VALUE,realCreate!=nullptr);
}
template<class T> struct LocalCom
{
    T *p=nullptr;
    LocalCom()=default;
    LocalCom(const LocalCom&)=delete;
    LocalCom& operator=(const LocalCom&)=delete;
    ~LocalCom(){if(p)p->Release();}
};
static void describeObject(const char *name,IUnknown *object,HRESULT hr)
{
    HMODULE module=nullptr;wchar_t path[1024]=L"unknown";
    if(object){void **vtable=*reinterpret_cast<void***>(object);
        if(GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(vtable[0]),&module))GetModuleFileNameW(module,path,1024);
    }
    log("DEVICE_INTERFACE name=%s hr=%08lx object=%p implementation=%ls\r\n",name,hr,object,path);
}
static void identifyDevice(IDXGISwapChain *swap)
{
    LocalCom<IUnknown> unknown;
    HRESULT hr=swap->GetDevice(__uuidof(IUnknown),reinterpret_cast<void**>(&unknown.p));
    describeObject("GetDevice(IUnknown)",unknown.p,hr);
    struct Probe{const char *name;const IID *iid;};
    const Probe probes[]={
        {"ID3D11Device",&__uuidof(ID3D11Device)},
        {"ID3D10Device",&__uuidof(ID3D10Device)},
        {"ID3D10Device1",&__uuidof(ID3D10Device1)},
        {"ID3D12Device",&__uuidof(ID3D12Device)},
        {"ID3D12CommandQueue",&__uuidof(ID3D12CommandQueue)},
        {"IDXGIDevice",&__uuidof(IDXGIDevice)}};
    for(const auto &probe:probes){
        LocalCom<IUnknown> direct;
        hr=swap->GetDevice(*probe.iid,reinterpret_cast<void**>(&direct.p));
        describeObject(probe.name,direct.p,hr);
        if(unknown.p){LocalCom<IUnknown> query;hr=unknown.p->QueryInterface(*probe.iid,reinterpret_cast<void**>(&query.p));
            log("DEVICE_QI name=%s hr=%08lx object=%p\r\n",probe.name,hr,query.p);
        }
    }
    LocalCom<IUnknown> buffer;
    hr=swap->GetBuffer(0,__uuidof(IUnknown),reinterpret_cast<void**>(&buffer.p));
    describeObject("BackBuffer(IUnknown)",buffer.p,hr);
    if(buffer.p){
        LocalCom<ID3D11Texture2D> tex11;hr=buffer.p->QueryInterface(__uuidof(ID3D11Texture2D),reinterpret_cast<void**>(&tex11.p));describeObject("BackBuffer.ID3D11Texture2D",tex11.p,hr);
        LocalCom<ID3D12Resource> res12;hr=buffer.p->QueryInterface(__uuidof(ID3D12Resource),reinterpret_cast<void**>(&res12.p));describeObject("BackBuffer.ID3D12Resource",res12.p,hr);
    }
}
static IDirectInput8W *inputInterface;
static IDirectInputDevice8W *inputDevices[2];
static LONG inputMin[2][2],inputMax[2][2];
static bool inputInitialized;
static bool compensateCrosshair=true;
static HANDLE widescreenReadyEvent;
static bool widescreenReady;
static HANDLE fullWidthAimEvent;
static bool fullWidthAimActive;
static double aimX[2]={0.35,0.65},aimY[2]={0.5,0.5};
static bool aimMoved[2];
static bool inputReverseY[2];
static int imageScalePercent[2]={200,200};
static IDirectInputDevice8W *otherInputs[16];
static wchar_t otherNames[16][MAX_PATH];
static unsigned otherCount;
static HWND inputWindow;
static BOOL CALLBACK enumerateInput(const DIDEVICEINSTANCEW *instance,void*)
{
    if(otherCount>=16)return DIENUM_STOP;
    wchar_t guid[80];StringFromGUID2(instance->guidInstance,guid,80);
    log("INPUT_DEVICE name=%ls product=%ls guid=%ls\r\n",instance->tszInstanceName,instance->tszProductName,guid);
    IDirectInputDevice8W *device=nullptr;
    HRESULT hr=inputInterface->CreateDevice(instance->guidInstance,&device,nullptr);
    if(FAILED(hr))return DIENUM_CONTINUE;
    hr=device->SetDataFormat(&c_dfDIJoystick2);
    if(SUCCEEDED(hr))hr=device->SetCooperativeLevel(inputWindow,DISCL_NONEXCLUSIVE|DISCL_BACKGROUND);
    if(FAILED(hr)){device->Release();return DIENUM_CONTINUE;}
    device->Acquire();
    otherInputs[otherCount]=device;
    wcsncpy(otherNames[otherCount],instance->tszInstanceName,MAX_PATH-1);
    ++otherCount;
    return DIENUM_CONTINUE;
}
static void readVJoy(HWND window,LONG64 frame)
{
    if(!inputInitialized){
        inputInitialized=true;
        HRESULT hr=DirectInput8Create(GetModuleHandleW(nullptr),DIRECTINPUT_VERSION,IID_IDirectInput8W,reinterpret_cast<void**>(&inputInterface),nullptr);
        log("INPUT_INIT interface_hr=%08lx\r\n",hr);
        if(FAILED(hr))return;
        wchar_t config[1024];GetModuleFileNameW(diagnosticModule,config,1024);
        wchar_t *slash=wcsrchr(config,L'\\');if(!slash)return;
        slash[1]=0;
        if(wcslen(config)+20>=1024)return;
        wcscat(config,L"ZeusCrosshair.ini");
        compensateCrosshair=GetPrivateProfileIntW(L"Widescreen",L"CrosshairCompensation",1,config)!=0;
        for(int p=0;p<2;p++){
            wchar_t text[80];const wchar_t *section=p?L"Player2":L"Player1";
            inputReverseY[p]=GetPrivateProfileIntW(section,L"ReverseY",0,config)!=0;
            imageScalePercent[p]=int(GetPrivateProfileIntW(section,L"ScalePercent",200,config));
            if(imageScalePercent[p]<10)imageScalePercent[p]=10;
            if(imageScalePercent[p]>400)imageScalePercent[p]=400;
            GetPrivateProfileStringW(section,L"DeviceGUID",L"",text,80,config);
            GUID guid={};hr=CLSIDFromString(text,&guid);
            if(FAILED(hr) || !text[0]){log("INPUT_INIT port=%d missing/invalid GUID\r\n",p+1);continue;}
            hr=inputInterface->CreateDevice(guid,&inputDevices[p],nullptr);
            if(FAILED(hr)){log("INPUT_INIT port=%d CreateDevice failed=%08lx\r\n",p+1,hr);continue;}
            hr=inputDevices[p]->SetDataFormat(&c_dfDIJoystick2);
            if(SUCCEEDED(hr))hr=inputDevices[p]->SetCooperativeLevel(window,DISCL_NONEXCLUSIVE|DISCL_BACKGROUND);
            if(FAILED(hr)){log("INPUT_INIT port=%d setup failed=%08lx\r\n",p+1,hr);inputDevices[p]->Release();inputDevices[p]=nullptr;continue;}
            for(int axis=0;axis<2;axis++){
                DIPROPRANGE range={};range.diph.dwSize=sizeof(range);range.diph.dwHeaderSize=sizeof(range.diph);range.diph.dwHow=DIPH_BYOFFSET;range.diph.dwObj=axis?DIJOFS_Y:DIJOFS_X;
                hr=inputDevices[p]->GetProperty(DIPROP_RANGE,&range.diph);
                inputMin[p][axis]=SUCCEEDED(hr)?range.lMin:0;inputMax[p][axis]=SUCCEEDED(hr)?range.lMax:65535;
            }
            hr=inputDevices[p]->Acquire();
            log("INPUT_INIT port=%d acquire_hr=%08lx x_range=%ld,%ld y_range=%ld,%ld\r\n",p+1,hr,inputMin[p][0],inputMax[p][0],inputMin[p][1],inputMax[p][1]);
        }
        inputWindow=window;
        if(loggingEnabled)inputInterface->EnumDevices(DI8DEVCLASS_GAMECTRL,enumerateInput,nullptr,DIEDFL_ATTACHEDONLY);
    }
    for(int p=0;p<2;p++)if(inputDevices[p]){
        DIJOYSTATE2 state={};HRESULT hr=inputDevices[p]->Poll();
        if(FAILED(hr))inputDevices[p]->Acquire();
        hr=inputDevices[p]->GetDeviceState(sizeof(state),&state);
        if(FAILED(hr)){if(frame==1 || frame%30==0)log("INPUT_SAMPLE frame=%lld port=%d read_failed=%08lx\r\n",frame,p+1,hr);continue;}
        const double xRange=double(inputMax[p][0])-inputMin[p][0],yRange=double(inputMax[p][1])-inputMin[p][1];
        const double x=xRange>0?(double(state.lX)-inputMin[p][0])/xRange:0.5;
        const double rawY=yRange>0?(double(state.lY)-inputMin[p][1])/yRange:0.5;
        const double y=inputReverseY[p]?1-rawY:rawY;
        if(x<0.49 || x>0.51 || y<0.49 || y>0.51)aimMoved[p]=true;
        if(compensateCrosshair && !widescreenReady){
            if(!widescreenReadyEvent){wchar_t eventName[96];swprintf(eventName,96,L"Local\\ZeusWidescreenApplied-%lu",GetCurrentProcessId());widescreenReadyEvent=OpenEventW(SYNCHRONIZE,FALSE,eventName);}
            if(widescreenReadyEvent && WaitForSingleObject(widescreenReadyEvent,0)==WAIT_OBJECT_0){widescreenReady=true;log("AIM_COMPENSATION active scale_x=0.75 input_unchanged=1\r\n");}
        }
        if(widescreenReady && !fullWidthAimActive){
            if(!fullWidthAimEvent){wchar_t eventName[96];swprintf(eventName,96,L"Local\\ZeusFullWidthAim-%lu",GetCurrentProcessId());fullWidthAimEvent=OpenEventW(SYNCHRONIZE,FALSE,eventName);}
            if(fullWidthAimEvent && WaitForSingleObject(fullWidthAimEvent,0)==WAIT_OBJECT_0){fullWidthAimActive=true;log("FULL_WIDTH_AIM active crosshair_range=0_to_1 both_players=1\r\n");}
        }
        if(aimMoved[p]){
            const double physicalX=x<0?0:(x>1?1:x);
            aimX[p]=(compensateCrosshair && widescreenReady && !fullWidthAimActive)?0.5+0.75*(physicalX-0.5):physicalX;
            aimY[p]=y<0?0:(y>1?1:y);
            if(frame==1 || frame%30==0)log("AIM_MAPPING frame=%lld port=%d physical_x=%.6f displayed_x=%.6f y=%.6f active=%d\r\n",frame,p+1,physicalX,aimX[p],aimY[p],int(compensateCrosshair && widescreenReady && !fullWidthAimActive));
        }
        if(frame==1 || frame%30==0)log("INPUT_SAMPLE frame=%lld port=%d raw=%ld,%ld normalized=%.4f,%.4f y_reversed=%d tracking=%d\r\n",frame,p+1,state.lX,state.lY,x,y,int(inputReverseY[p]),int(aimMoved[p]));
    }
    if(frame==1 || frame%60==0)for(unsigned i=0;i<otherCount;i++){
        DIJOYSTATE2 state={};if(FAILED(otherInputs[i]->Poll()))otherInputs[i]->Acquire();
        HRESULT hr=otherInputs[i]->GetDeviceState(sizeof(state),&state);
        if(SUCCEEDED(hr))log("INPUT_ENUM_SAMPLE frame=%lld device=%u name=%ls axes=%ld,%ld,%ld,%ld,%ld,%ld sliders=%ld,%ld\r\n",frame,i,otherNames[i],state.lX,state.lY,state.lZ,state.lRx,state.lRy,state.lRz,state.rglSlider[0],state.rglSlider[1]);
        else log("INPUT_ENUM_SAMPLE frame=%lld device=%u failed=%08lx\r\n",frame,i,hr);
    }
}

#include "png_crosshairs.inc"
#include "d3d12_overlay.inc"

static bool drawMarkers(IDXGISwapChain *swap,LONG64 frame)
{
    const bool report=frame==1 || frame%300==0;
    LocalCom<ID3D11Device> device;
    HRESULT hr=swap->GetDevice(__uuidof(ID3D11Device),reinterpret_cast<void**>(&device.p));
    if(FAILED(hr)){
        LocalCom<IUnknown> unknown;
        if(SUCCEEDED(swap->GetDevice(__uuidof(IUnknown),reinterpret_cast<void**>(&unknown.p))))hr=unknown.p->QueryInterface(__uuidof(ID3D11Device),reinterpret_cast<void**>(&device.p));
    }
    if(FAILED(hr))return draw12(swap,frame);
    if(report)log("CROSSHAIR_D3D11 overlay_disabled_for_diagnostic frame=%lld\r\n",frame);
    return false;
}
static bool observeFrame(IDXGISwapChain *swap,UINT interval,UINT flags,const char *method)
{
    if(flags & DXGI_PRESENT_TEST)return false;
    DXGI_SWAP_CHAIN_DESC d={};HRESULT descHR=swap->GetDesc(&d);
    if(SUCCEEDED(descHR) && d.OutputWindow==probeWindow)return false;
    LONG64 frame=InterlockedIncrement64(&frames);
    if(frame==1)identifyDevice(swap);
    if(SUCCEEDED(descHR))readVJoy(d.OutputWindow,frame);
    if(frame==1 || frame%300==0){log("ZEUS_FRAME method=%s frame=%lld interval=%u flags=%u desc_hr=%08lx size=%ux%u window=%p windowed=%d\r\n",method,frame,interval,flags,descHR,d.BufferDesc.Width,d.BufferDesc.Height,d.OutputWindow,d.Windowed);}
    return drawMarkers(swap,frame);
}
static HRESULT STDMETHODCALLTYPE present(IDXGISwapChain *swap,UINT interval,UINT flags)
{
    observeFrame(swap,interval,flags,"Present");
    HRESULT hr=realPresent(swap,interval,flags);
    if(FAILED(hr))log("PRESENT failed=%08lx\r\n",hr);
    return hr;
}

static void importAddress(unsigned rva,const char *name)
{
    void *address=nullptr;SIZE_T got=0;
    const auto base=reinterpret_cast<unsigned char*>(GetModuleHandleW(nullptr));
    if(!ReadProcessMemory(GetCurrentProcess(),base+rva,&address,sizeof(address),&got) || got!=sizeof(address)){
        log("LIVE_IMPORT name=%s read_failed=%lu\r\n",name,GetLastError());return;
    }
    HMODULE owner=nullptr;wchar_t path[1024]=L"unknown";
    if(address && GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_UNCHANGED_REFCOUNT,reinterpret_cast<LPCWSTR>(address),&owner))GetModuleFileNameW(owner,path,1024);
    log("LIVE_IMPORT name=%s address=%p owner=%ls\r\n",name,address,path);
}
static DWORD WINAPI investigateDXGI(LPVOID)
{
    for(const wchar_t *name : {L"VK_LAYER_PATH",L"VK_INSTANCE_LAYERS",L"VK_LOADER_DEBUG"}){wchar_t value[2048]={};DWORD n=GetEnvironmentVariableW(name,value,2048);log("VULKAN_ENV name=%ls length=%lu value=%ls\r\n",name,n,value);}
    // Packed code may finish loading after the proxy is attached.
    BYTE *hostBase=reinterpret_cast<BYTE*>(GetModuleHandleW(nullptr));
    for(unsigned attempt=0;attempt<200;attempt++){
        bool ready=true;SIZE_T got=0;
        for(const auto &site:projectionSites){BYTE signature[12]={};if(!ReadProcessMemory(GetCurrentProcess(),hostBase+site.rva,signature,site.length,&got)||got!=site.length||memcmp(signature,site.original,site.length)){ready=false;break;}}
        const double expectedConstants[]={128.5,200.5,512.0};double constants[3]={};
        if(ready && (!ReadProcessMemory(GetCurrentProcess(),hostBase+0x141460,constants,sizeof(constants),&got)||memcmp(constants,expectedConstants,sizeof(constants))))ready=false;
        if(ready){applyWidescreen();break;}
        if(attempt==199)log("WIDESCREEN skipped: loaded host code did not become ready in two seconds\r\n");
        Sleep(10);
    }
    Sleep(250);
    log("DXGI_WORKER starting pid=%lu\r\n",GetCurrentProcessId());
    importAddress(0x8e2140,"D3D11CreateDeviceAndSwapChain");
    importAddress(0x8e2150,"CreateDXGIFactory1");
    InitOnceExecuteOnce(&initOnce,initialize,nullptr,nullptr);
    wchar_t system[1024];UINT n=GetSystemDirectoryW(system,1024);
    HMODULE dxgi=nullptr;
    if(n && n+10<1024){wcscat(system,L"\\dxgi.dll");dxgi=LoadLibraryW(system);}
    using FactoryFn=HRESULT(WINAPI*)(REFIID,void**);
    auto factoryFn=dxgi?reinterpret_cast<FactoryFn>(GetProcAddress(dxgi,"CreateDXGIFactory1")):nullptr;
    IDXGIFactory1 *factory=nullptr;
    HRESULT hr=factoryFn?factoryFn(__uuidof(IDXGIFactory1),reinterpret_cast<void**>(&factory)):E_FAIL;
    log("DXGI_BOOTSTRAP factory_result=%08lx\r\n",hr);
    if(factory)factory->Release();
    log("DXGI_FACTORY creation hooks disabled for isolation test\r\n");
    log("DXGI_STAGE before_register_window\r\n");
    WNDCLASSW wc={};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=diagnosticModule;wc.lpszClassName=L"ZeusDiagnosticHiddenProbe";
    ATOM registered=RegisterClassW(&wc);
    log("DXGI_STAGE before_create_window registered=%u error=%lu\r\n",registered,GetLastError());
    probeWindow=CreateWindowExW(0,wc.lpszClassName,L"Zeus diagnostic hidden probe",WS_OVERLAPPED,0,0,64,64,nullptr,nullptr,diagnosticModule,nullptr);
    log("DXGI_STAGE after_create_window window=%p error=%lu\r\n",probeWindow,GetLastError());
    if(probeWindow && realCreate){
        DXGI_SWAP_CHAIN_DESC desc={};desc.BufferDesc.Width=64;desc.BufferDesc.Height=64;desc.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;desc.SampleDesc.Count=1;desc.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;desc.BufferCount=1;desc.OutputWindow=probeWindow;desc.Windowed=TRUE;desc.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
        IDXGISwapChain *swap=nullptr;ID3D11Device *device=nullptr;ID3D11DeviceContext *context=nullptr;
        log("DXGI_STAGE before_hardware_create\r\n");
        hr=realCreate(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&desc,&swap,&device,nullptr,&context);
        log("DXGI_PROBE driver=hardware result=%08lx\r\n",hr);
        if(FAILED(hr)){
            if(context){context->Release();context=nullptr;}if(device){device->Release();device=nullptr;}if(swap){swap->Release();swap=nullptr;}
            log("DXGI_STAGE before_warp_create\r\n");
            hr=realCreate(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,0,nullptr,0,D3D11_SDK_VERSION,&desc,&swap,&device,nullptr,&context);
            log("DXGI_PROBE driver=warp result=%08lx\r\n",hr);
        }
        if(SUCCEEDED(hr) && swap){log("DXGI_STAGE before_present_hook\r\n");hookSwapChain(swap);log("DXGI_STAGE after_present_hook\r\n");}
        if(context)context->Release();
        if(device)device->Release();
        if(swap)swap->Release();
    }else log("DXGI_PROBE unavailable window=%p create=%d\r\n",probeWindow,realCreate!=nullptr);
    Sleep(5000);
    importAddress(0x8e2140,"D3D11CreateDeviceAndSwapChain");
    importAddress(0x8e2150,"CreateDXGIFactory1");
    log("DXGI_WORKER complete frames_observed=%lld\r\n",InterlockedCompareExchange64(&frames,0,0));
    if(probeWindow)DestroyWindow(probeWindow);
    // Retain its HWND value solely to exclude any late probe presentation.
    UnregisterClassW(wc.lpszClassName,diagnosticModule);
    return 0;
}
static HRESULT STDMETHODCALLTYPE present1(IDXGISwapChain1 *swap,UINT interval,UINT flags,const DXGI_PRESENT_PARAMETERS *params)
{
    const bool drawn=observeFrame(swap,interval,flags,"Present1");
    if(drawn && params && (params->DirtyRectsCount || params->pScrollRect)){
        DXGI_PRESENT_PARAMETERS fullFrame={};
        return realPresent1(swap,interval,flags,&fullFrame);
    }
    return realPresent1(swap,interval,flags,params);
}
static void hookSwapChain(IDXGISwapChain *swap)
{
        AcquireSRWLockExclusive(&hookLock);
        void **table=*reinterpret_cast<void***>(swap);DWORD old;
        if(table[8]==reinterpret_cast<void*>(present))log("Present already hooked\r\n");
        else if(realPresent && table[8]!=reinterpret_cast<void*>(realPresent))log("Different Present implementation: skipped\r\n");
        else if(VirtualProtect(&table[8],sizeof(void*),PAGE_READWRITE,&old)){
            realPresent=reinterpret_cast<PresentFn>(table[8]);InterlockedExchangePointer(&table[8],reinterpret_cast<void*>(present));DWORD ignored;VirtualProtect(&table[8],sizeof(void*),old,&ignored);log("Present hook installed\r\n");
        }else log("Present hook failed error=%lu\r\n",GetLastError());
        ReleaseSRWLockExclusive(&hookLock);
        IDXGISwapChain1 *swap1=nullptr;
        if(SUCCEEDED(swap->QueryInterface(__uuidof(IDXGISwapChain1),reinterpret_cast<void**>(&swap1)))){
            AcquireSRWLockExclusive(&hookLock);
            void **table1=*reinterpret_cast<void***>(swap1);DWORD old1;
            if(table1[22]!=reinterpret_cast<void*>(present1) && (!realPresent1 || table1[22]==reinterpret_cast<void*>(realPresent1)) && VirtualProtect(&table1[22],sizeof(void*),PAGE_READWRITE,&old1)){
                realPresent1=reinterpret_cast<Present1Fn>(table1[22]);InterlockedExchangePointer(&table1[22],reinterpret_cast<void*>(present1));DWORD ignored;VirtualProtect(&table1[22],sizeof(void*),old1,&ignored);log("Present1 hook installed\r\n");
            }
            ReleaseSRWLockExclusive(&hookLock);swap1->Release();
        }
    }
extern "C" __declspec(dllexport) HRESULT WINAPI D3D11CreateDeviceAndSwapChain(IDXGIAdapter *adapter,D3D_DRIVER_TYPE driver,HMODULE software,UINT flags,const D3D_FEATURE_LEVEL *levels,UINT levelCount,UINT sdk,const DXGI_SWAP_CHAIN_DESC *desc,IDXGISwapChain **swap,ID3D11Device **device,D3D_FEATURE_LEVEL *feature,ID3D11DeviceContext **context)
{
    InitOnceExecuteOnce(&initOnce,initialize,nullptr,nullptr);
    if(!realCreate)return HRESULT_FROM_WIN32(ERROR_PROC_NOT_FOUND);
    static thread_local bool forwarding=false;
    if(forwarding){log("FORWARDER_RECURSION blocked: reentrant create\r\n");return E_FAIL;}
    struct ForwardingGuard{bool &flag;ForwardingGuard(bool &f):flag(f){flag=true;}~ForwardingGuard(){flag=false;}} guard(forwarding);
    log("CREATE driver=%u flags=%u sdk=%u requested=%ux%u\r\n",driver,flags,sdk,desc?desc->BufferDesc.Width:0,desc?desc->BufferDesc.Height:0);
    HRESULT hr=realCreate(adapter,driver,software,flags,levels,levelCount,sdk,desc,swap,device,feature,context);
    log("CREATE result=%08lx swap=%p\r\n",hr,SUCCEEDED(hr) && swap?*swap:nullptr);
    if(SUCCEEDED(hr) && swap && *swap)hookSwapChain(*swap);
    return hr;
}
