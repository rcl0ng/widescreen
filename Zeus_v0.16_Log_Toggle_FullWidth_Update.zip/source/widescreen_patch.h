#include <tlhelp32.h>
#include <vector>
#include <cwctype>
#include "projection_sites.h"

// One startup attempt only. No on-disk executable changes.
static void applyWidescreen(){
 static LONG attempted=0;if(InterlockedCompareExchange(&attempted,1,0))return;
 wchar_t exePath[1024];GetModuleFileNameW(nullptr,exePath,1024);
 const wchar_t *name=wcsrchr(exePath,L'\\');name=name?name+1:exePath;
 if(_wcsicmp(name,L"TeknoZeus.exe")){log("WIDESCREEN skipped: process is not TeknoZeus.exe\r\n");return;}
 wchar_t ini[1024];GetModuleFileNameW(diagnosticModule,ini,1024);wchar_t *slash=wcsrchr(ini,L'\\');
 if(!slash)return;wcscpy(slash+1,L"ZeusCrosshair.ini");
 if(!GetPrivateProfileIntW(L"Widescreen",L"Enabled",0,ini)){log("WIDESCREEN disabled in INI\r\n");return;}
 int argc=0;LPWSTR *argv=CommandLineToArgvW(GetCommandLineW(),&argc);bool wide=false,invasion=false;
 if(!argv){log("WIDESCREEN skipped: command-line parse failed\r\n");return;}
 for(int i=1;i<argc;i++){
  if(!_wcsicmp(argv[i],L"--aspect")&&i+1<argc)wide=!_wcsicmp(argv[++i],L"16:9");
  if(!_wcsicmp(argv[i],L"invasnab")||!_wcsicmp(argv[i],L"invasion"))invasion=true;
 }
 LocalFree(argv);
 if(!wide||!invasion){log("WIDESCREEN skipped: requires Invasion and --aspect 16:9\r\n");return;}
 BYTE *base=reinterpret_cast<BYTE*>(GetModuleHandleW(nullptr));
 const size_t count=sizeof(projectionSites)/sizeof(projectionSites[0]);
 BYTE saved[14][12];SIZE_T got=0;
 for(size_t i=0;i<count;i++){
  auto &s=projectionSites[i];
  if(!ReadProcessMemory(GetCurrentProcess(),base+s.rva,saved[i],s.length,&got)||got!=s.length||memcmp(saved[i],s.original,s.length)){
   log("WIDESCREEN skipped: instruction mismatch RVA=%08lx\r\n",s.rva);return;
  }
 }
 const double expected[]={128.5,200.5,512.0};double values[3];
 if(!ReadProcessMemory(GetCurrentProcess(),base+0x141460,values,sizeof(values),&got)||memcmp(values,expected,sizeof(values))){log("WIDESCREEN skipped: projection constants mismatch\r\n");return;}
 BYTE *arena=nullptr;uintptr_t origin=reinterpret_cast<uintptr_t>(base)&~uintptr_t(65535);
 for(uintptr_t delta=65536;delta<0x70000000&&!arena;delta+=65536){
  arena=static_cast<BYTE*>(VirtualAlloc(reinterpret_cast<void*>(origin+delta),65536,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
  if(!arena&&origin>delta)arena=static_cast<BYTE*>(VirtualAlloc(reinterpret_cast<void*>(origin-delta),65536,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE));
 }
 if(!arena){log("WIDESCREEN skipped: no nearby trampoline memory\r\n");return;}
 BYTE replacement[14][12];
 for(size_t i=0;i<count;i++){
  auto &s=projectionSites[i];BYTE *stub=arena+i*64;size_t n=0;
  memcpy(stub,s.original,s.mulLength);n+=s.mulLength;
  // vmulpd/vmulsd xmm0,xmm0,[rip+scale]; no registers or flags clobbered.
  BYTE multiply[]={0xc5,static_cast<BYTE>(s.vector?0xf9:0xfb),0x59,0x05,0,0,0,0};
  int32_t disp=static_cast<int32_t>((stub+48)-(stub+n+8));memcpy(multiply+4,&disp,4);
  memcpy(stub+n,multiply,8);n+=8;
  memcpy(stub+n,s.original+s.mulLength,s.length-s.mulLength);n+=s.length-s.mulLength;
  stub[n]=0xe9;disp=static_cast<int32_t>((base+s.rva+s.length)-(stub+n+5));memcpy(stub+n+1,&disp,4);
  const double scale[2]={0.75,0.75};memcpy(stub+48,scale,sizeof(scale));
  memset(replacement[i],0x90,12);replacement[i][0]=0xe9;disp=static_cast<int32_t>(stub-(base+s.rva+5));memcpy(replacement[i]+1,&disp,4);
 }
 DWORD arenaOld;if(!VirtualProtect(arena,65536,PAGE_EXECUTE_READ,&arenaOld)){VirtualFree(arena,0,MEM_RELEASE);log("WIDESCREEN skipped: trampoline protection failed\r\n");return;}
 FlushInstructionCache(GetCurrentProcess(),arena,65536);
 // Prepare protections before suspending peers, avoiding heap/loader work while stopped.
 DWORD pageRva[]={0x67000,0xbd000},old[2]={};size_t prepared=0;
 for(;prepared<2;prepared++)if(!VirtualProtect(base+pageRva[prepared],4096,PAGE_EXECUTE_READWRITE,&old[prepared]))break;
 if(prepared!=2){for(size_t i=0;i<prepared;i++){DWORD x;VirtualProtect(base+pageRva[i],4096,old[i],&x);}VirtualFree(arena,0,MEM_RELEASE);log("WIDESCREEN skipped: code protection failed\r\n");return;}
 std::vector<HANDLE> peers;peers.reserve(4096);bool safe=true;
 HANDLE snapshot=CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD,0);THREADENTRY32 entry={};entry.dwSize=sizeof(entry);
 if(snapshot==INVALID_HANDLE_VALUE)safe=false;
 else if(!Thread32First(snapshot,&entry))safe=false;
 else do{
  if(entry.th32OwnerProcessID!=GetCurrentProcessId()||entry.th32ThreadID==GetCurrentThreadId())continue;
  if(peers.size()==peers.capacity()){safe=false;break;}
  HANDLE t=OpenThread(THREAD_SUSPEND_RESUME|THREAD_GET_CONTEXT,FALSE,entry.th32ThreadID);
  if(!t){safe=false;break;}
  if(SuspendThread(t)==DWORD(-1)){CloseHandle(t);safe=false;break;}
  peers.push_back(t);CONTEXT c={};c.ContextFlags=CONTEXT_CONTROL;
  if(!GetThreadContext(t,&c)){safe=false;break;}
  uintptr_t rva=c.Rip-reinterpret_cast<uintptr_t>(base);
  if((rva>=0x66700&&rva<0x67c00)||(rva>=0xbc250&&rva<0xbd800)){safe=false;break;}
 }while(Thread32Next(snapshot,&entry));
 if(snapshot!=INVALID_HANDLE_VALUE)CloseHandle(snapshot);
 if(safe){
  for(size_t i=0;i<count;i++)if(memcmp(base+projectionSites[i].rva,saved[i],projectionSites[i].length)){safe=false;break;}
  if(safe){for(size_t i=0;i<count;i++)memcpy(base+projectionSites[i].rva,replacement[i],projectionSites[i].length);FlushInstructionCache(GetCurrentProcess(),base,0x105253);}
 }
 for(HANDLE t:peers){ResumeThread(t);CloseHandle(t);}
 for(size_t i=0;i<2;i++){DWORD x;VirtualProtect(base+pageRva[i],4096,old[i],&x);}
 if(!safe){VirtualFree(arena,0,MEM_RELEASE);log("WIDESCREEN skipped: could not safely patch startup threads\r\n");return;}
 installGuestAimHook(base,ini);
 wchar_t eventName[96];swprintf(eventName,96,L"Local\\ZeusWidescreenApplied-%lu",GetCurrentProcessId());
 HANDLE readyEvent=CreateEventW(nullptr,TRUE,TRUE,eventName);
 log("WIDESCREEN_READY_EVENT handle=%p error=%lu\r\n",readyEvent,readyEvent?0:GetLastError());
 log("WIDESCREEN applied scale_x=0.75 scale_y=1.0 sites=%llu aspect=16:9\r\n",static_cast<unsigned long long>(count));
 for(size_t i=0;i<count;i++)log("WIDESCREEN_SITE RVA=%08lx vector=%d\r\n",projectionSites[i].rva,int(projectionSites[i].vector));
}
