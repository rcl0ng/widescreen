$ErrorActionPreference = 'Stop'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fff'
$logRoot = Join-Path $PSScriptRoot 'logs'
if (-not (Test-Path -LiteralPath $logRoot)) { Write-Host 'No logs folder. Enable [General] Logging=1 and run Zeus if logs are needed.'; exit 0 }
$out = Join-Path $logRoot ('Zeus-Runtime-' + $stamp)
New-Item -ItemType Directory -Path $out | Out-Null
$logs = @(Get-ChildItem -LiteralPath $logRoot -Filter 'zeus-crosshair-diagnostic-*.log' -File | Sort-Object LastWriteTime -Descending | Select-Object -First 2)
foreach ($log in $logs) { Copy-Item -LiteralPath $log.FullName -Destination $out }
Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'ZeusCrosshair.ini') -Destination $out
Compress-Archive -Path (Join-Path $out '*') -DestinationPath ($out + '.zip')
Write-Host ('Logs saved: ' + $out + '.zip')
