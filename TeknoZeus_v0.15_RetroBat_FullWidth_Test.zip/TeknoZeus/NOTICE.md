# Notice

## Project status

TeknoZeus project-owned source is private and is not offered under an open-source
or other public license. All rights are reserved. No permission is granted to
use, copy, modify, publish, distribute, sublicense, or create derivative works
from project-owned material without separate written permission from the
applicable owner.

Third-party terms identified below apply only to their respective components.
They do not license TeknoZeus as a whole or any project-owned material.

Game ROMs, firmware, disk images, keys, NVRAM, artwork, captures, and other
proprietary game or system media are not part of this repository.

## Incorporated third-party components

- ENet under its MIT license, retained at third_party/enet/LICENSE.
- LZ4 1.9.5 under its BSD-2-Clause license, retained at third_party/lz4/LICENSE.
- SDL3 3.4.10, fetched for Windows feedback builds under its zlib license;
  installed packages retain licenses/SDL3/LICENSE.txt.

- Standalone ADSP-21xx, TMS320C3x, and DCS2 components adapted from
  individually BSD-3-Clause MAME work by Aaron Giles.
- Disk-ASIC-related adaptations credited to Aaron Giles, R. Belmont, and
  Ryan Holtz under BSD-3-Clause.
- Khronos OpenXR headers and Windows loader under their upstream
  Apache-2.0/MIT terms, with retained materials under
  third_party/openxr/licenses.
- Vulkan-related third-party material under the terms retained at
  third_party/vulkan/LICENSE.txt.
- CRT presentation shader adapted from Timothy Lottes' public-domain CRT
  shader through TeknoViper, retained in src/host/shaders/crt_lottes.inc.

## BSD-3-Clause notices and terms

The following copyright notices apply to the incorporated BSD-3-Clause
components:

- ADSP-21xx, TMS320C3x, and DCS2: Copyright Aaron Giles.
- Disk ASIC: Copyright Aaron Giles, R. Belmont, and Ryan Holtz.

The applicable upstream MAME headers identify their copyright holders without
stating a year; no year has been invented here.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.
3. Neither the name of the copyright holder nor the names of its contributors
   may be used to endorse or promote products derived from this software
   without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

## SDL3 local duration fix

The bundled SDL 3.4.10 includes the local Windows DirectInput duration fix in
`cmake/SDL3HapticDuration.cmake`. It preserves the infinite-effect sentinel
instead of multiplying it into a finite duration. This is a local modification,
not an unmodified upstream SDL release. SDL remains under its zlib license.
