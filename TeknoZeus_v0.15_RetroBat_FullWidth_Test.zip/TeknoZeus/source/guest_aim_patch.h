// Invasion v5.0 guest-code experiment, applied at an emulated gun-read boundary.
// Both players share the same guest hit-test and screen-to-world routines.
using GunReadFn=uint32_t(__fastcall*)(void*,const uint32_t*);
static GunReadFn originalGunRead;
static bool guestAimRequested;
static void tryGuestAimPatch(BYTE *state){
 if(!guestAimRequested || !state)return;
 static ULONGLONG nextCheck=0;ULONGLONG now=GetTickCount64();if(now<nextCheck)return;nextCheck=now+250;
 BYTE *start=nullptr,*end=nullptr;SIZE_T got=0;
 if(!ReadProcessMemory(GetCurrentProcess(),state+0x50110,&start,sizeof(start),&got) ||
    !ReadProcessMemory(GetCurrentProcess(),state+0x50118,&end,sizeof(end),&got) ||
    !start || uintptr_t(end)<uintptr_t(start)+0x100000)return;
 auto readWords=[&](DWORD address,uint32_t *out,size_t count){SIZE_T n=0;return ReadProcessMemory(GetCurrentProcess(),start+address*4,out,count*4,&n)&&n==count*4;};
 const uint32_t rayOriginal[]={0x0fa30000,0x07030002,0x0a23afbe,0x17a0afa3,0x0a000003,0x17a1afa4,0x0a010003,0x0ea30000};
 const uint32_t hitOriginal[]={0x0a20ae0d,0x20c1038a,0x0a010000,0x01a1afa3,0x20c2044a,0x0a020000,0x01a2afa4};
 uint32_t ray[8],hit[7],gap[7];
 if(!readWords(0x1119b,ray,8)||!readWords(0xefa3,hit,7)||!readWords(0xc219,gap,7))return;
 if(ray[4]==0x6200c219 && hit[2]==0x6200c21c)return;
 if(memcmp(ray,rayOriginal,sizeof(ray))||memcmp(hit,hitOriginal,sizeof(hit)))return;
 for(uint32_t word:gap)if(word)return;
 // Seven-word alignment gap between JUMPLOW and .text in the decoded COFF.
 // Full C3x float 0x002aaaab represents 4/3 to single-precision accuracy.
 const uint32_t helpers[]={0x0a000003,0x0a20c21f,0x78800000,0x0a010000,0x0a61f400,0x78800000,0x002aaaab};
 // This callback runs on the emulation thread, before executing either patched
 // guest instruction. Write helpers first, then switch the two aligned words.
 SIZE_T written=0;
 if(!WriteProcessMemory(GetCurrentProcess(),start+0xc219*4,helpers,sizeof(helpers),&written)||written!=sizeof(helpers)){log("GUEST_AIM helpers_write_failed\r\n");return;}
 const uint32_t rayCall=0x6200c219,hitCall=0x6200c21c;
 if(!WriteProcessMemory(GetCurrentProcess(),start+0x1119f*4,&rayCall,4,&written)||written!=4){WriteProcessMemory(GetCurrentProcess(),start+0xc219*4,gap,28,&written);log("GUEST_AIM ray_write_failed\r\n");return;}
 if(!WriteProcessMemory(GetCurrentProcess(),start+0xefa5*4,&hitCall,4,&written)||written!=4){WriteProcessMemory(GetCurrentProcess(),start+0x1119f*4,&rayOriginal[4],4,&written);WriteProcessMemory(GetCurrentProcess(),start+0xc219*4,gap,28,&written);log("GUEST_AIM hit_write_failed\r\n");return;}
 wchar_t readyName[96];swprintf(readyName,96,L"Local\\ZeusFullWidthAim-%lu",GetCurrentProcessId());
 HANDLE ready=CreateEventW(nullptr,TRUE,TRUE,readyName);
 log("FULL_WIDTH_AIM_EVENT handle=%p error=%lu\r\n",ready,ready?0:GetLastError());
 log("GUEST_AIM applied version=Invasion5 ray_guest=01119f hit_guest=00efa5 gain=1.3333333730697632 hit_scale=0.75 both_players=1\r\n");
}
static uint32_t __fastcall compensatedGunRead(void *closure,const uint32_t *address){
 BYTE *state=nullptr;SIZE_T got=0;
 if(ReadProcessMemory(GetCurrentProcess(),static_cast<BYTE*>(closure)+8,&state,sizeof(state),&got))tryGuestAimPatch(state);
 return originalGunRead(closure,address);
}
static void installGuestAimHook(BYTE *base,const wchar_t *ini){
 guestAimRequested=GetPrivateProfileIntW(L"Widescreen",L"FullWidthAim",0,ini)!=0;
 if(!guestAimRequested){log("GUEST_AIM disabled in INI\r\n");return;}
 const BYTE ramLayoutExpected[]={0x48,0x8b,0x81,0x10,0x01,0x05,0x00};
 BYTE ramLayoutActual[7];SIZE_T layoutBytes=0;
 if(!ReadProcessMemory(GetCurrentProcess(),base+0x7752c,ramLayoutActual,7,&layoutBytes)||memcmp(ramLayoutActual,ramLayoutExpected,7)){log("GUEST_AIM hook_skipped: RAM layout mismatch\r\n");return;}
 const BYTE expected[]={0x48,0x89,0x5c,0x24,0x10,0x57,0x48,0x83,0xec,0x30,0x48,0x8b,0x59,0x08};
 BYTE actual[sizeof(expected)];SIZE_T got=0;
 if(!ReadProcessMemory(GetCurrentProcess(),base+0x76e90,actual,sizeof(actual),&got)||memcmp(actual,expected,sizeof(actual))){log("GUEST_AIM hook_skipped: gun-read instructions mismatch\r\n");return;}
 void **slot=reinterpret_cast<void**>(base+0x142240);void *current=nullptr;
 if(!ReadProcessMemory(GetCurrentProcess(),slot,&current,sizeof(current),&got)||current!=base+0x76e90){log("GUEST_AIM hook_skipped: gun-read table mismatch\r\n");return;}
 DWORD old;if(!VirtualProtect(slot,sizeof(void*),PAGE_READWRITE,&old)){log("GUEST_AIM hook_skipped: table protection failed\r\n");return;}
 originalGunRead=reinterpret_cast<GunReadFn>(current);
 InterlockedExchangePointer(slot,reinterpret_cast<void*>(compensatedGunRead));DWORD ignored;VirtualProtect(slot,sizeof(void*),old,&ignored);
 log("GUEST_AIM hook installed; waiting for matching loaded game code\r\n");
}
